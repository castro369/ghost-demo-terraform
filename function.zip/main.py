import os
import sqlalchemy

connection_name = "drone-shuttles-demo:europe-west1:ghost-db-a58d3a3e"
table_name1 = "posts"
table_name2 = "posts_authors"
table_name3 = "posts_meta"
table_name4 = "posts_tags"
db_name = os.environ["DB_NAME"]
db_user = os.environ["DB_USER"]
db_password = os.environ["DB_PASS"]

driver_name = 'mysql+pymysql'
query_string = dict({"unix_socket": "/cloudsql/{}".format(connection_name)})

# If the type of your table_field value is a string, surround it with double quotes.

def delete(request):
    request_json = request.get_json()
    stmt1 = sqlalchemy.text('SET FOREIGN_KEY_CHECKS=0;')
    stmt2 = sqlalchemy.text('DELETE FROM {};'.format(table_name1))
    stmt3 = sqlalchemy.text('DELETE FROM {};'.format(table_name2))
    stmt4 = sqlalchemy.text('DELETE FROM {};'.format(table_name3))
    stmt5 = sqlalchemy.text('DELETE FROM {};'.format(table_name4))
    stmt6 = sqlalchemy.text('SET FOREIGN_KEY_CHECKS=1;')

    db = sqlalchemy.create_engine(
      sqlalchemy.engine.url.URL(
        drivername=driver_name,
        username=db_user,
        password=db_password,
        database=db_name,
        query=query_string,
      ),
      pool_size=5,
      max_overflow=2,
      pool_timeout=30,
      pool_recycle=1800
    )
    try:
        with db.connect() as conn:
            conn.execute(stmt1)
            conn.execute(stmt2)
            conn.execute(stmt3)
            conn.execute(stmt4)
            conn.execute(stmt5)
            conn.execute(stmt6)
    except Exception as e:
        return 'Error: {}'.format(str(e))
    return 'ok'